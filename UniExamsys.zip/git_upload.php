<?php
// git_upload.php - Direct Browser Uploader to GitHub API
session_start();
require_once __DIR__ . '/config.php';

$error = '';
$success = '';
$filesUploaded = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['start_upload'])) {
    $token = trim($_POST['token']);
    $repo = trim($_POST['repo']); // Expected: "username/repository"
    
    if (empty($token) || empty($repo)) {
        $error = "Please provide both your GitHub Access Token and Repository Path.";
    } else {
        // Scan directory recursively
        $baseDir = __DIR__;
        $allFiles = [];
        
        function scanFolder($dir, &$results) {
            $files = scandir($dir);
            foreach ($files as $key => $value) {
                $path = realpath($dir . DIRECTORY_SEPARATOR . $value);
                if (!is_dir($path)) {
                    // Exclude specific files
                    $filename = basename($path);
                    if ($filename !== 'git_upload.php' && $filename !== 'examsys_backup.sql' && $filename !== 'final_standee_design.png') {
                        $results[] = $path;
                    }
                } else if ($value != "." && $value != "..") {
                    // Exclude specific folders
                    if ($value !== 'scratch' && $value !== 'temp_mysql_data' && $value !== '.git') {
                        scanFolder($path, $results);
                    }
                }
            }
        }
        
        scanFolder($baseDir, $allFiles);
        
        // Start uploading via GitHub REST API
        $successCount = 0;
        $failedCount = 0;
        
        foreach ($allFiles as $filePath) {
            $relativePath = str_replace($baseDir . DIRECTORY_SEPARATOR, '', $filePath);
            $relativePath = str_replace('\\', '/', $relativePath); // normalize path for github
            
            $content = base64_encode(file_get_contents($filePath));
            $url = "https://api.github.com/repos/$repo/contents/$relativePath";
            
            // Check if file already exists to get its SHA (to overwrite if needed)
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_USERAGENT, 'ExamsysUploader');
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Authorization: token $token",
                "Accept: application/vnd.github.v3+json"
            ]);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            $sha = null;
            if ($httpCode == 200) {
                $fileInfo = json_decode($response, true);
                $sha = $fileInfo['sha'];
            }
            
            // Upload / Update file
            $data = [
                'message' => "Upload $relativePath via Examsys Web Uploader",
                'content' => $content
            ];
            if ($sha) {
                $data['sha'] = $sha;
            }
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_USERAGENT, 'ExamsysUploader');
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Authorization: token $token",
                "Accept: application/vnd.github.v3+json",
                "Content-Type: application/json"
            ]);
            $result = curl_exec($ch);
            $putHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($putHttpCode == 200 || $putHttpCode == 201) {
                $successCount++;
                $filesUploaded[] = "[OK] $relativePath";
            } else {
                $failedCount++;
                $errDetails = json_decode($result, true);
                $filesUploaded[] = "[FAIL] $relativePath - " . ($errDetails['message'] ?? 'Unknown error');
            }
        }
        
        $success = "Upload completed! Successfully uploaded $successCount files. ($failedCount failed).";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Examsys - GitHub Repository Web Uploader</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .uploader-card {
            background: var(--white);
            border-radius: var(--radius);
            padding: 40px;
            box-shadow: var(--shadow-lg);
            width: 100%;
            max-width: 650px;
            margin: 50px auto;
            border: 1px solid var(--gray-light);
        }
        .instructions-list {
            background: #F8FAFC;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 24px;
            font-size: 14px;
            color: var(--gray);
            border-left: 4px solid var(--primary);
            text-align: left;
        }
        .instructions-list ol {
            margin-left: 20px;
            margin-top: 10px;
        }
        .instructions-list li {
            margin-bottom: 8px;
        }
        .log-box {
            background: #0F172A;
            color: #38BDF8;
            font-family: monospace;
            padding: 15px;
            border-radius: 8px;
            height: 200px;
            overflow-y: auto;
            text-align: left;
            font-size: 13px;
            margin-top: 20px;
        }
    </style>
</head>
<body style="background-color: var(--light); display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 20px;">
    <div class="uploader-card">
        <div style="text-align: center; margin-bottom: 25px;">
            <img src="assets/images/logo.png" alt="University of Sahiwal Logo" style="height: 65px; object-fit: contain; margin-bottom: 15px;">
            <h1 style="font-size: 24px; font-weight: 700; color: var(--dark);">GitHub Web Repository Uploader</h1>
            <p style="color: var(--gray); font-size: 14px;">Directly upload all your final project files to GitHub via API</p>
        </div>

        <div class="instructions-list">
            <strong>How to get your GitHub Token & Repo:</strong>
            <ol>
                <li>Log in to your account on <a href="https://github.com" target="_blank" style="color:var(--primary); font-weight:600;">github.com</a> and create a repository named <code>UniExamsys</code>.</li>
                <li>Go to <strong>Settings</strong> (click your profile icon -> Settings) -> scroll down and click <strong>Developer settings</strong> (at the very bottom).</li>
                <li>Click <strong>Personal access tokens</strong> -> <strong>Tokens (classic)</strong> -> click <strong>Generate new token (classic)</strong>.</li>
                <li>Write a name in Note, check the top checkbox: <strong>[x] repo</strong> (Full control of private/public repositories), and click <strong>Generate token</strong> at the bottom.</li>
                <li>Copy the generated token key (it starts with <code>ghp_</code>) and paste it below!</li>
            </ol>
        </div>

        <?php if($success): ?>
            <div class="alert alert-success" style="margin-bottom: 20px;"><?= $success ?></div>
        <?php endif; ?>
        <?php if($error): ?>
            <div class="alert alert-error" style="margin-bottom: 20px;"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>GitHub Access Token (starts with ghp_)</label>
                <input type="password" name="token" class="form-control" placeholder="ghp_xxxxxxxxxxxxxxxxxxxx" required>
            </div>
            <div class="form-group">
                <label>GitHub Repository Path (username/repository)</label>
                <input type="text" name="repo" class="form-control" placeholder="yourusername/UniExamsys" required>
            </div>
            
            <button type="submit" name="start_upload" class="btn btn-block" style="background: var(--primary);">🚀 Start GitHub Upload</button>
        </form>

        <?php if(!empty($filesUploaded)): ?>
            <div class="log-box">
                <strong>Upload logs:</strong><br>
                <?php foreach($filesUploaded as $log): ?>
                    <?= htmlspecialchars($log) ?><br>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div style="margin-top: 25px; text-align: center; font-size: 13px;">
            <a href="index.php" style="color: var(--gray); text-decoration: none;">← Go to Home Page</a>
        </div>
    </div>
</body>
</html>
